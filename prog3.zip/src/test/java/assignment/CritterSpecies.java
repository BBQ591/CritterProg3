package assignment;

import java.util.ArrayList;
import java.util.List;

public class CritterSpecies {
    public List critterBehavior;
    public String name;
    public CritterSpecies(String name2, List critterBehavior2) {
        critterBehavior = critterBehavior2;
        name = name2;
    }
}
